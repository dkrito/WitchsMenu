# Unity-Project-Template
A Default Project Template that I've created to use on my own projects. Feel free to use, share and implement your own changes.

Some of the code in this project might be taken from sources such as Stack-Overflow. If anyone feels they need to be mentioned in this project, I would be happy to add their information here.

Recommended C# [script template](http://www.sarpersoher.com/my-unity-new-c-script-template/) by [Sarper Soher](http://www.sarpersoher.com/).
